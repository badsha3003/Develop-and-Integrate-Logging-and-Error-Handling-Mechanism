using Logging_and_error_handling_mechanism;
using Serilog;

var builder = WebApplication.CreateBuilder(args);



builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("logs/log-.txt", rollingInterval: RollingInterval.Day)
    .WriteTo.MSSqlServer(
         builder.Configuration.GetConnectionString("DefaultConnection"),
        sinkOptions: new Serilog.Sinks.MSSqlServer.MSSqlServerSinkOptions { TableName = "Logs", AutoCreateSqlTable = true }
    )
    .Enrich.FromLogContext()
    .CreateLogger();


builder.Host.UseSerilog();

var app = builder.Build();


if (app.Environment.IsDevelopment())
{
        app.UseDeveloperExceptionPage();
}
else
{
        app.UseExceptionHandler("/error");
 }

    app.UseSwagger();
    app.UseSwaggerUI();


app.UseAuthorization();
app.UseMiddleware<GlobalExceptionMiddleware>();
app.MapControllers();

app.Run();
