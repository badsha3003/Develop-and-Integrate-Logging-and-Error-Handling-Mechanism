﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Logging_and_error_handling_mechanism.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExampleController : ControllerBase
    {
        [HttpGet("success")]
        public IActionResult Success()
        {
            return Ok(new { Message = "This is a successful response." });
        }

        [HttpGet("error")]
        public IActionResult Error()
        {
            throw new Exception("This is a simulated exception.");
        }
    }
}
